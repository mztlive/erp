# W23 · 销售单执行投影

> 状态：草稿  
> 页面模式：M2 高密度查询列表 + M4 对象中心  
> 主要路由：`/commerce/execution-projections`、`/commerce/execution-projections/{projectionId}`  
> 主要角色：运营、销售、系统管理员 / 运维  
> 最后更新：2026-08-01

## 1. 定位与目标

### 1.1 用户目标

用户进入此工作面，应能回答：

1. 哪些已生效卡券销售版本仍等待商城接收、接收失败或结果未知？
2. 某个执行投影对应哪张 ERP 销售单、哪个不可变销售版本和哪次商城确认？
3. 商城实际收到的执行字段是什么，为什么当前版本被阻断？
4. 当前应等待自动重试、查询最终结果、人工重试，还是进入错误中心处理？
5. 从运营监控列表能否直接回到 W05 销售单“协同”子区理解完整业务上下文？

### 1.2 业务目标

- `sales_order_projection` 只是 ERP 已生效卡券销售版本向商城下发的执行投影，不是第二张销售单，也不是可独立编辑的业务单据。
- 每个 ERP 销售单版本向一个目标商城恰好对应一份不可变投影修订。
- 投影只包含商城执行所需字段，不泄露成交金额、配赠、税率、开票、应收和玩法规则。
- 销售单生效与商城执行接收是两个连续但独立的阶段；投递失败不回退销售事实、销售版本或应收。
- 单张销售单的协同状态优先在 W05 内看懂；W23 服务于跨单监控、失败治理和批量处理。

### 1.3 不在本工作面完成

- 不创建、修改、作废销售单或销售变更单；进入 W05。
- 不允许用户手工改投影字段、替换销售版本或伪造商城确认。
- 不展示或维护商城玩法、卡号、卡密、手机号绑定、余额或制卡进度。
- 不把失败投影重新生成成“修正版”；业务内容变化必须先在 W05 形成新的销售版本。
- 不在此关闭接口差异或编辑原始报文；人工异常闭环进入 W29。
- 不处理商品发布；进入 W22。

## 2. 用户、权限与数据范围

| 角色 | 默认入口 | 可见范围 | 主要动作 |
| --- | --- | --- | --- |
| 运营 | 失败 / 待确认视图 | 被授权商城和卡券业务范围 | 查看执行字段、查询结果、重试、转错误处理 |
| 销售 | W05 销售单协同子区 | 本人负责或协作客户的销售单 | 查看接收状态和失败说明，不能重写投影 |
| 销售领导 | 从销售单中心进入 | 授权团队销售单 | 只读查看审批生效后的投影结果 |
| 系统管理员 / 运维 | W23 全局异常视图 | 获授权商城与组织 | 批量处理失败、查询结果、进入 W29 |
| 管理层 / 财务 | 按需只读 | 授权范围 | 查看接收水位；不会因财务权限看到投影外字段 |

### 2.1 权限与字段边界

| 情况 | 页面行为 |
| --- | --- |
| 无 W23 模块权限 | 不展示独立列表入口；有 W05 权限时仍可在销售单协同子区查看该单摘要 |
| 有模块权限但无销售数据范围 | 显示无数据范围，不返回全量投影后前端过滤 |
| 有销售单查看权限但无重试权限 | 内容可读；动作禁用并展示服务端阻塞原因 |
| 无客户敏感字段权限 | 客户名称按字段策略掩码；投影中的商城客户外部身份只显示受控短引用 |
| 有财务字段权限 | W23 仍不展示成交金额、税率、应收等非投影字段，权限不会扩大对象边界 |
| 权限在页面打开时被收回 | 清除缓存中的客户和错误摘要，内容切为无权限态 |

所有操作由 `allowedActions` 和 `actionBlockers` 决定。前端不能因为状态显示为“失败”就默认用户有重试权限。

## 3. 入口、路由与任务页签

| 场景 | 入口 | URL / 页签行为 | 返回位置 |
| --- | --- | --- | --- |
| 查看跨单投影列表 | 侧栏“执行投影” | `/commerce/execution-projections`；筛选写入 URL | 返回恢复筛选、分页与滚动 |
| 从销售单查看协同状态 | W05 “协同”子区 | 默认留在 `sales-order:{salesOrderId}` 页签内展示当前投影摘要 | 不强制新开 W23 |
| 查看投影完整历史 | W05 “查看投影历史”或列表行 | `/commerce/execution-projections/{projectionId}?revision={revisionId}` | 返回 W05 时聚焦协同子区 |
| 处理失败 | W01 / W02 待办、失败指标、W29 | 打开 W23 投影对象并定位 `deliveryId` | 原任务和队列上下文保留 |
| 批量处理 | W23 失败筛选 | 选择条件进入 URL；选择快照不直接写 URL | 完成后保留原筛选 |
| 刷新浏览器 | 任意详情 | 恢复稳定投影、选中修订和投递项 | 当前投影 |

W23 对象页签身份为 `sales-projection:{projectionId}`，标题为 `投影 · {销售单号}`。W05 和 W23 可以分别存在任务页签，但同一 W23 投影重复打开只聚焦原页签。选中历史修订或投递尝试不改变页签身份。

## 4. 页面布局

### 4.1 列表页（1440×900）

```text
┌ PageHeader：执行投影                    数据水位 09:36 [刷新] [批量处理]
├ MetricStrip：[待发送] [发送/重试中] [待确认超时] [失败/转人工] [已确认]
├ ListToolbar：SavedView | 搜索 | 商城 | 接收状态 | 来源 | 发生时间 | 更多筛选
├ SelectionScopeBar（选择失败项后）：已选 N 项 / 当前筛选全部 [影响预览]
├ BusinessTableFrame
│ 销售单（固定） | ERP版本 | 投影版本 | 来源 | 客户 | 商城 | 接收状态
│ 商城已确认版 | 最近尝试 | 失败原因 | 操作（固定）
└ 服务端分页 / BackgroundJobProgress（批量任务存在时）
```

### 4.2 对象中心（1440×900）

```text
┌ DocumentHeader：销售单号 · ERP版本 · 投影版本 · 目标商城
│ 销售事实：已生效    投影投递：重试中    商城确认：待确认      [查询结果] [更多]
├ 关键提示：投影不是销售单副本；失败不回退销售事实或应收
├ 锚点：概览 | 执行内容 | 投递历史 | 版本对应 | 差异与错误 | 审计
├ 概览：来源销售版本、投影来源、当前商城已确认版、延迟和责任人
├ 执行内容：客户外部身份、卡券类目、履约期限、面额、数量、卡形态、生效时间
├ 投递历史：状态、尝试、下次动作、商城确认、脱敏失败摘要
├ 版本对应：ERP 销售版本 ↔ 投影版本 ↔ 商城确认版本
└ 差异与错误：对账差异、人工任务及 W29 入口
```

### 4.3 区域说明

| 区域 | 目的 | 主组件 | 是否固定 |
| --- | --- | --- | --- |
| 三段状态轨 | 区分 ERP 生效、消息投递和商城确认 | `DocumentHeader` `StatusTrackSummary` | 顶部固定 |
| 非写者提示 | 防止用户把投影当成可改单据 | `Alert` | 存在失败或用户有写权限时固定可见 |
| 执行内容 | 读取商城真正应接收的白名单字段 | `DocumentSection` | 否 |
| 版本对应 | 证明一对一来源与当前确认水位 | `RevisionTimeline` | 否 |
| 投递历史 | 查看每次尝试和下一步 | `AsyncSectionState` / 历史表 | 否 |
| 正式结果 | 固定显示查询、重试和批量任务结果 | `FormalActionResult` | 动作后主区顶部 |

## 5. 展示内容与字段

### 5.1 身份与状态

| 区域 | 字段 | 用户文案 | 数据来源 | 口径 / 格式 | 权限规则 |
| --- | --- | --- | --- | --- | --- |
| 身份 | `salesOrderId` / `salesOrderNo` | 销售单 | `sales_order` | 稳定身份；列表固定列 | 按销售单数据范围 |
| 版本 | `salesOrderRevisionNo` | ERP 销售版本 | `sales_order_projection_revision.sales_order_revision_id` | 不可变版本号 | 可见投影即可见 |
| 版本 | `projectionRevisionNo` | 执行投影版本 | 投影修订 | 与 ERP 版本一对一 | 可见 |
| 来源 | `projectionSource` | 版本来源 | 迁移基线 / ERP 销售版本 | 迁移基线明确标注，不声称新销售版本 | 可见 |
| 商城 | `targetMallName` | 目标商城 | 稳定投影 | 按商城范围 | 可见 |
| 销售事实 | `salesOrderStatus` | 销售单状态 | W05 查询投影 | 只读摘要；失败时仍显示已生效 | 按销售权限 |
| 接收 | `deliveryStatus` | 商城接收状态 | `sales_order_projection_delivery` | 待发送、发送中、重试中、已确认、失败、转人工 | 可见 |
| 水位 | `currentAckedRevisionNo` | 商城最后确认版本 | `current_acked_revision_id` | 无确认时明确“尚未确认” | 可见 |
| 延迟 | `pendingDuration` / `nextAttemptAt` | 等待时长 / 下次处理 | 服务端投递查询 | 服务端基于公司时钟返回 | 可见 |

### 5.2 执行投影白名单字段

| 字段 | 用户文案 | 数据来源 | 展示规则 |
| --- | --- | --- | --- |
| `customerExternalIdentity` | 商城客户引用 | 投影修订 | 默认短引用，可按权限复制完整稳定 ID |
| `voucherCategoryExternalIdentity` | 商城卡券类目 | 投影修订 | 同时展示 ERP 类目名称与商城稳定映射 |
| `voucherExpiryAt` | 履约期限 | 投影修订 | 销售单表头级一个值 |
| `faceValue` | 面额 | 投影修订唯一明细 | 金额格式化；它是执行字段，不展示成交金额 |
| `cardCount` | 数量 | 投影修订唯一明细 | 必须来自恰好一条卡券明细 |
| `cardForm` | 卡形态 | 投影修订唯一明细 | 电子卡 / 实体卡 |
| `effectiveAt` | ERP 生效时间 | 投影修订 | 绝对时间 + 工作时区 |
| `contentHash` | 内容指纹 | 投影修订 | 审计区展示短摘要 |

W23 在任何角色下都不得增加玩法规则、成交金额、配赠、税率、开票要求或应收字段。需要理解完整商业事实时进入 W05。

### 5.3 投递与错误

| 字段 | 用户文案 | 数据来源 | 说明 |
| --- | --- | --- | --- |
| `attemptCount` / `lastAttemptAt` | 尝试次数 / 最近尝试 | 投递 | 尝试次数不等于版本数 |
| `nextAttemptAt` | 下次自动处理 | 投递 | 不可重试时为空并给出原因 |
| `mallAckAt` | 商城确认时间 | 投递 | 只有明确确认后展示 |
| `mallExecutionBaseline` | 商城执行基线 | 投递 | 受控稳定引用，不展示商城玩法内容 |
| `errorCode` / `errorSummary` | 失败原因 | 脱敏错误摘要 | 不显示密钥、原始报文或堆栈 |
| `reconciliationStatus` | 版本核对 | 对账差异 | 差异只生成任务，不覆盖任一侧事实 |
| `errorTaskId` | 人工处理任务 | W29 关联 | 显示责任方、状态和入口 |

## 6. 搜索、筛选、排序与默认视图

| 能力 | 默认值 | URL 状态 | 行为 |
| --- | --- | --- | --- |
| 搜索 | 空 | `q` | 精确销售单号、投影编号；客户名按权限模糊搜索 |
| 目标商城 | 全部有权商城 | `mall` | 服务端过滤 |
| 接收状态 | 待处理 + 失败 | `deliveryStatus` | 运营默认关注未确认；销售从 W05 进入不套此默认 |
| 投影来源 | 全部 | `source` | 迁移基线 / ERP 销售版本 |
| 超时分组 | 全部 | `latency` | 正常、接近 SLA、超过 SLA；阈值来自服务端配置 |
| 版本差异 | 全部 | `reconciliation` | 只查看 ERP 当前与商城确认不一致项 |
| 负责人 | 当前角色范围 | `owner` | 自动重试、运营协同、人工错误责任队列 |
| 排序 | 风险优先 | `sort=risk.desc,createdAt.asc` | 结果未知/转人工 → 失败 → 超时 → 待发送 → 已确认 |

- 单击列表行打开 `detail` 半屏，可读完整白名单字段、来源版本、最新投递和错误摘要。
- 指标筛选必须有选中态和当前筛选摘要，结果数量由服务端返回。
- 选择“当前筛选全部”时创建 `bulk_selection_snapshot`，冻结数据截止水位、对象版本和目标集合。
- 已确认项默认不参与批量重试；服务端执行时逐项跳过状态已变化、权限收回或版本不匹配项。

## 7. 操作契约

| 操作 | 入口 | 权限 / 前置条件 | 确认 | 成功结果 | 失败恢复 |
| --- | --- | --- | --- | --- | --- |
| 查看销售单 | 列表 / 对象中心 | 有 W05 对象权限 | 无 | 聚焦 W05 同一销售单并定位“协同” | 无权限时保留投影摘要，不泄露商业字段 |
| 查询最终结果 | 发送超时 / 结果未知 | `QUERY_RESULT`；存在可查询原请求 | 无 | 更新明确已确认、明确失败或仍未知 | 仍未知停留当前项并提供 W29 入口 |
| 重试投递 | 失败项 | `RETRY`；错误可重试、没有并发发送、版本仍有效 | 展示销售版本、商城和原幂等键 | 沿原投影修订继续投递，固定显示操作编号 | 超时先查询；不得生成新投影修订 |
| 批量查询结果 | 选择栏 | `BULK_QUERY`；选择快照有效 | `BatchImpactPreview` | 后台任务逐项查询并汇总 | 显示成功/仍未知/跳过/失败 |
| 批量重试 | 选择栏 | `BULK_RETRY`；仅明确可重试项 | 预览状态、商城和数量 | 后台任务沿各项原幂等键执行 | 逐项保留原因，不改变销售事实 |
| 转人工处理 | 对象中心 | `ESCALATE`；已超自动上限或明确人工错误 | 说明责任队列与影响 | 创建 / 关联 W29 错误任务 | 重复请求返回既有任务 |
| 复制投影摘要 | 执行内容 | 有字段查看权限 | 无 | 复制白名单字段及稳定引用 | 被掩码字段不进入剪贴板 |

### 7.1 禁止的动作

- W23 不提供“新建投影”“编辑投影”“修改接收状态”“改销售版本”或“重新生成内容”。
- 投影由已生效销售版本自动形成。内容错误时返回 W05 走销售变更单，形成新的销售版本和新的投影修订。
- 重试和人工重放使用原幂等键“ERP 销售单号 + ERP 销售单版本 + 目标商城”。
- 商城接收失败时，界面不得提供回退销售单、删除应收或删除投影的动作。
- 对账差异只能进入 W29 核对和追加处理记录，不能在 W23 选择一侧直接覆盖另一侧。

## 8. 数据契约

### 8.1 列表查询

```ts
type ExecutionProjectionListQuery = {
  q?: string
  mallIds?: string[]
  deliveryStatuses?: string[]
  sources?: Array<"MIGRATION_BASELINE" | "ERP_SALES_REVISION">
  latencyBand?: "normal" | "near_sla" | "over_sla"
  reconciliationStatus?: string
  ownerScope?: string
  sort: string
  page: number
  pageSize: number
}

type ExecutionProjectionRow = {
  projectionId: string
  projectionRevisionId: string
  projectionRevisionNo: number
  projectionSource: "MIGRATION_BASELINE" | "ERP_SALES_REVISION"
  salesOrderId: string
  salesOrderNo: string
  salesOrderRevisionId: string
  salesOrderRevisionNo: number
  salesOrderStatus: string
  customerLabel: string
  targetMallId: string
  targetMallName: string
  currentAckedRevisionNo?: number
  delivery: {
    deliveryId: string
    status: string
    attemptCount: number
    lastAttemptAt?: string
    nextAttemptAt?: string
    mallAckAt?: string
    errorSummary?: string
  }
  reconciliationStatus?: string
  allowedActions: string[]
  actionBlockers: Array<{ action: string; code: string; message: string }>
}
```

列表总数、指标和行数据必须使用同一权限/数据范围版本与查询水位。前端不得用当前页行数计算待确认或失败总量。

### 8.2 对象中心查询

```ts
type ExecutionProjectionView = {
  identity: {
    projectionId: string
    salesOrderId: string
    salesOrderNo: string
    targetMallId: string
    targetMallName: string
  }
  selectedRevision: {
    projectionRevisionId: string
    revisionNo: number
    projectionSource: "MIGRATION_BASELINE" | "ERP_SALES_REVISION"
    salesOrderRevisionId: string
    salesOrderRevisionNo: number
    customerExternalIdentity: string
    voucherCategoryExternalIdentity: string
    voucherExpiryAt: string
    faceValue: string
    cardCount: string
    cardForm: string
    effectiveAt: string
    contentHash: string
  }
  currentAckedRevisionId?: string
  revisionLinks: Array<{
    salesOrderRevisionId: string
    projectionRevisionId: string
    deliveryStatus: string
    mallAckAt?: string
  }>
  deliveries: Array<{
    deliveryId: string
    status: string
    attemptCount: number
    lastAttemptAt?: string
    nextAttemptAt?: string
    mallAckAt?: string
    mallExecutionBaseline?: string
    errorCode?: string
    errorSummary?: string
    errorTaskId?: string
  }>
  allowedActions: string[]
  actionBlockers: Array<{ action: string; code: string; message: string }>
  fieldPermissions: Record<string, "full" | "masked" | "hidden">
  objectVersion: string
  queriedAt: string
}
```

### 8.3 提交与后台任务

```ts
type ProjectionDeliveryCommand = {
  projectionId: string
  projectionRevisionId: string
  deliveryId: string
  action: "QUERY_RESULT" | "RETRY" | "ESCALATE"
  expectedObjectVersion: string
  requestId: string
}

type ProjectionDeliveryResult = {
  operationId: string
  deliveryId: string
  result: "ACKED" | "FAILED" | "STILL_UNKNOWN" | "RETRY_SCHEDULED" | "ESCALATED"
  errorTaskId?: string
  occurredAt: string
  nextAction?: string
}
```

- `RETRY` 只引用既有投影修订和投递，不提交任何投影业务字段。
- 批量动作先创建服务端选择快照，再以唯一 `requestId` 注册 `background_job`；逐项结果可为成功、仍未知、跳过或失败。
- 请求超时后按 `requestId` / `operationId` 查询结果；前端不自行判定成功。
- 投递与 outbox 是后台过程；页面刷新不得新建投递或推进状态。

### 8.4 前端边界

- 前端只做执行字段格式化和服务端状态文案映射，不从销售单重新组装投影。
- 不比较金额、税率或应收，也不把 W05 当前字段拼进历史投影。
- “商城版本落后 N 版”、等待时长和 SLA 分类由服务端返回；前端可展示但不作为正式状态来源。
- 原始请求/响应只允许展示脱敏摘要；任何密钥、卡号、卡密和完整客户外部凭据都不进入浏览器。

## 9. 页面状态矩阵

| 状态 | 页面表现 | 可执行动作 | 恢复方式 |
| --- | --- | --- | --- |
| 初载 | 按列表 / 对象中心成稿结构显示 Skeleton | 应用壳可用 | 查询完成原位替换 |
| 刷新 | 保留旧状态轨和历史，显示轻量刷新 | 阅读、打开 W05；正式动作前重验 | 成功更新时间，失败保留缓存 |
| 空数据 | “当前没有执行投影” | 返回销售单或清除范围 | 销售版本生效后自动出现 |
| 筛选无结果 | 展示当前状态/商城筛选摘要 | 清除筛选 | 恢复默认视图 |
| 无数据范围 | 不显示全局 0 指标 | 查看角色 / 申请范围 | 权限更新后重查 |
| 查询失败 | 有缓存保留并标陈旧；无缓存显示失败态 | 重试 | 查询恢复 |
| 数据陈旧 | 展示投递水位和最后查询时间 | 刷新、查询最终结果 | 服务端状态追平 |
| 字段级隐藏 | 客户和外部引用按策略掩码 | 其它有权动作可用 | 权限更新后重查 |
| 待发送 / 发送中 | 状态轨显示当前阶段和下次检查时间 | 查看销售单；禁止重复重试 | 后台推进 |
| 自动重试中 | 保留原失败原因、尝试次数与下次时间 | 按权限查询结果 | 自动成功或转人工 |
| 投递失败 | 销售事实轨仍显示已生效；投递轨失败 | 重试、转 W29 | 原幂等投递成功 |
| 结果未知 | 不显示成功、不移动到已确认筛选 | 查询最终结果、转人工 | 明确结果后更新 |
| 商城已确认 | 固定展示确认时间和商城执行基线 | 查看 W05 / 历史 | 新销售版本形成下一投影 |
| 版本差异 | 对应关系区显示 ERP 与商城版本，不自动选边 | 打开 W29 差异任务 | 人工核对闭环 |
| 后台批量任务 | 显示进度与逐项结果 | 查看、下载合规结果 | 原任务继续查询 |
| 权限收回 | 清除客户和错误摘要，切无权限态 | 返回有权模块 | 恢复后重查 |

## 10. 响应式、键盘与无障碍

| 视口 | 布局变化 | 保留内容 | 允许降级 |
| --- | --- | --- | --- |
| 1440×900 | 列表 6–8 行；对象中心三轨和版本对应同屏 | 销售单、ERP版、投影版、商城确认版、接收状态、主动作 | 无 |
| 1280×800 | 次要列进入列设置；详情右区变窄 | 身份、三版本、状态、错误摘要 | 负责人、最近尝试时间可隐藏 |
| 1024×768 | 图标侧栏；详情覆盖；工具栏换行 | 三段状态轨、白名单字段、查询结果动作 | 完整历史折叠 |
| 768×1024 | 导航抽屉；表格横滚；对象中心单列 | 销售单身份与操作列固定；失败与结果未知文案 | 版本对应改卡片；筛选进面板 |
| 375×812 | 紧凑只读卡片 | 销售单、投影版、商城状态、失败入口 | 不提供批量、重试和复杂治理；可查询简单结果或进入 W29 |

- `/` 聚焦列表搜索，方向键移动，Enter 打开详情预览。
- 三段状态轨提供可读文本和阶段位置；读屏器不得只听到颜色或图标名称。
- 查询/重试结果使用固定 `FormalActionResult` 和 `aria-live=polite`；结果未知使用 `role=alert`，但不反复播报轮询状态。
- 从 W05 返回后焦点恢复到“查看投影历史”触发源；从 W29 返回后聚焦原错误区。
- 确认框关闭后焦点返回原按钮；批量任务启动后焦点落到任务结果标题。

## 11. 与其他工作面的关系

| 来源 / 去向 | Wxx | 携带上下文 | 返回规则 |
| --- | --- | --- | --- |
| 今日工作台 / 待办 | W01 / W02 | `workItemId`、`projectionId`、失败筛选 | 返回聚焦原任务 |
| 销售单统一中心 | W05 | `salesOrderId`、`salesOrderRevisionId`、`section=collaboration` | W05 是单单据主入口；返回保留选中投影 |
| 商品发布 | W22 | 无直接内容写入；仅目标商城协同状态 | 返回保留原投影筛选 |
| 主责迁移 | W24 | `baselineProjectionRevisionId`、迁移批次 | 迁移基线只读；不在 W23 修改 |
| 商城消费订单 | W25 | 原销售单身份；消费不按投影版本归集 | 返回保留消费订单上下文 |
| 接口错误与对账 | W29 | `deliveryId`、`errorTaskId`、对账差异、原幂等键 | 处理后回 W23 刷新明确结果 |

W23 与 W05 的边界固定：W05 展示一张销售单的当前协同全貌，W23 展示跨销售单的投递运营面。两处读取同一投影事实，不形成两套写入口。

## 12. 验收清单

### 12.1 定位与页面

- [ ] 用户在 W05 协同子区即可看懂单张销售单当前投影和商城接收状态，无需先进入 W23。
- [ ] W23 能一次筛选出结果未知、失败、转人工、超过 SLA 和版本差异项。
- [ ] 1440×900 下列表露出 6–8 条有效数据行，销售单身份列和操作列固定。
- [ ] 对象中心一屏区分销售事实、投影投递和商城确认三条状态轨。
- [ ] 历史投影始终显示其来源销售版本，不被 W05 当前版本覆盖。

### 12.2 非第二写者边界

- [ ] W23 没有新建、编辑、删除投影或修改商城确认状态的入口。
- [ ] 投影字段只来自已生效销售版本的服务端投影修订，前端不重新组装。
- [ ] 成交金额、配赠、税率、开票、应收和玩法规则在任何角色下都不进入投影内容。
- [ ] 内容变化必须在 W05 走销售变更单，形成新销售版本后自动产生新投影。
- [ ] 接收失败不会回退销售版本、应收或旧版已完成执行事实。

### 12.3 幂等、异常与后台任务

- [ ] 一个 ERP 销售版本与目标商城只存在一份投影修订。
- [ ] 自动、人工和批量重试均使用原幂等键，不产生新投影修订。
- [ ] 结果未知先查询，未明确前不显示成功、不跳过、不进入已确认统计。
- [ ] 批量动作使用服务端选择快照，逐项重验权限、状态和版本。
- [ ] 对账差异只创建 / 打开 W29 任务，不覆盖 ERP 或商城事实。
- [ ] 正式结果固定显示操作编号、对象、时间和下一步，不只用 toast。

### 12.4 权限、状态与响应式

- [ ] 销售只能看到其负责/协作客户范围，运营和运维按商城与组织范围查看。
- [ ] 权限收回后不残留客户外部身份、错误摘要或缓存的敏感字段。
- [ ] §9 状态均完成组件或浏览器验收。
- [ ] 1440、1280、1024、768、375 五档视口符合 §10。
- [ ] 键盘可完成搜索、预览、打开 W05、查询结果和读取批量任务结果。

## 13. 待确认事项

| ID | 问题 | 影响 | 建议决策人 | 当前建议 |
| --- | --- | --- | --- | --- |
| Q1 | 商城执行投影确认的正常 SLA、超时分级和自动重试上限是多少？ | 指标、排序、告警和转人工时点 | 运维 + 商城负责人 | 按错误类别配置，由服务端返回 SLA 状态和下次动作时间 |
| Q2 | 运营与系统管理员分别可处理哪些错误类别？ | `allowedActions`、责任队列和审计 | 运营负责人 + 系统负责人 | 业务拒绝归运营协同；鉴权/连接归运维；映射差异按责任对象分派 |
| Q3 | W23 是否允许“当前筛选全部”批量重试，还是只允许逐页选择？ | 高风险批量影响与后台任务规模 | 运维负责人 | 允许服务端冻结选择快照，但结果未知项只查询、不直接重试 |
| Q4 | 商城执行基线稳定引用对销售和运营展示到什么粒度？ | 字段权限和排障能力 | 商城负责人 + 安全负责人 | 默认短引用；完整值仅授权排障角色可复制 |
| Q5 | 已确认历史投影在默认列表保留多长在线查询窗口？ | 默认筛选、分页规模与归档查询 | 运营 + 数据负责人 | 全历史可追溯；默认视图聚焦近 90 天或未闭环项 |

## 14. 业务依据

- `erp-phase-2.md` §8.1–§8.4：销售审批生效、执行投影字段、接收阻断、变更和商城执行边界。
- `erp-phase-2.md` §13：投影幂等、消息可靠性、版本对账与监控指标。
- `erp-phase-2.md` §15 P2-P04、§16、§17.2：W23 落点、角色职责和验收场景。
- `erp-data-model.md` §6.16：稳定投影、不可变修订、投递字段、一对一版本关系和禁止字段。
- `erp-data-model.md` §7.7、§8.4、§9.4：投递状态、结果未知、事务不变量和对账边界。
- `erp-mall-data-mapping.md` §3.6、§10.3：outbox、原幂等键、投影白名单与商城确认。
- `erp-ui-design.md` §3.4–§3.5、§4.3、§4.5、§6、§9–§11、§15：任务页签、响应式、M2/M4、二期协同与通用状态。
- `erp-ui-flows.md` §10.2：销售单协同子区优先呈现，W23 处理跨单批量失败。
